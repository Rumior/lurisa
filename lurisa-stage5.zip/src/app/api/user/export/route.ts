import { NextRequest, NextResponse } from 'next/server';
import { getToken } from 'next-auth/jwt';
import { authRateLimit } from '@/lib/rate-limit';
import { addExportJob } from '@/lib/queue';
import { logAudit } from '@/lib/audit';

export async function POST(req: NextRequest) {
  try {
    const token = await getToken({ req, secret: process.env.NEXTAUTH_SECRET });
    if (!token?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Strict rate limit for exports
    const rateLimit = await authRateLimit.export(token.id as string);
    if (!rateLimit.success) {
      return NextResponse.json(
        { error: 'Export rate limit exceeded. Max 3 per hour.' },
        { status: 429 }
      );
    }

    const userId = token.id;
    const jobId = `export-${userId}-${Date.now()}`;

    // Stage 5: Use BullMQ queue for async processing
    await addExportJob({
      userId,
      jobId,
      format: 'json',
    });

    await logAudit({
      userId,
      action: 'data.export.requested',
      details: `Export job ${jobId} queued`,
      ipAddress: req.headers.get('x-forwarded-for') || undefined,
    });

    return NextResponse.json({
      jobId,
      message: 'Export job queued. You will be notified when ready.',
      status: 'queued',
    });
  } catch (error) {
    console.error('Export error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

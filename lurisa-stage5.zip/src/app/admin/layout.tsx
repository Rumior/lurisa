import { getServerSession } from 'next-auth';
import { redirect } from 'next/navigation';
import { authOptions } from '@/lib/auth';

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.email || session.user.email !== process.env.ADMIN_EMAIL) {
    redirect('/');
  }
  return (
    <div className="min-h-screen bg-parchment-300 dark:bg-parchment-900">
      <header className="h-16 bg-indigo-500 text-parchment-100 flex items-center px-6">
        <span className="font-serif text-xl">lurisa Admin</span>
      </header>
      <main className="p-6">{children}</main>
    </div>
  );
}

import { NextResponse } from 'next/server';
import { withAuth } from 'next-auth/middleware';
import { authRateLimit } from './lib/rate-limit';

export default withAuth(
  async function middleware(req) {
    const token = req.nextauth.token;
    const pathname = req.nextUrl.pathname;

    // Admin route protection
    if (pathname.startsWith('/(admin)') || pathname.startsWith('/admin')) {
      // In production, check for admin role
      // For now, block admin routes in production unless explicitly enabled
      if (process.env.NODE_ENV === 'production' && !process.env.ADMIN_ENABLED) {
        return NextResponse.redirect(new URL('/', req.url));
      }
    }

    // API rate limiting
    if (pathname.startsWith('/api/') && token?.id) {
      const rateLimit = await authRateLimit.api(token.id as string);
      if (!rateLimit.success) {
        return NextResponse.json(
          { error: 'Rate limit exceeded' },
          { 
            status: 429, 
            headers: { 
              'Retry-After': String(Math.ceil((rateLimit.reset - Date.now()) / 1000)),
              'X-RateLimit-Limit': String(rateLimit.limit),
              'X-RateLimit-Remaining': String(rateLimit.remaining),
            } 
          }
        );
      }
    }

    // Add security headers to all responses
    const response = NextResponse.next();
    response.headers.set('X-Request-ID', crypto.randomUUID());

    return response;
  },
  {
    callbacks: {
      authorized({ req, token }) {
        if (req.nextUrl.pathname.startsWith('/api/auth')) return true;
        if (req.nextUrl.pathname === '/') return true;
        if (req.nextUrl.pathname.startsWith('/login')) return true;
        if (req.nextUrl.pathname.startsWith('/register')) return true;
        if (req.nextUrl.pathname.startsWith('/privacy')) return true;
        if (req.nextUrl.pathname.startsWith('/terms')) return true;
        if (req.nextUrl.pathname.startsWith('/api/health')) return true;
        if (req.nextUrl.pathname.startsWith('/(dashboard)')) return token !== null;
        return true;
      },
    },
  }
);

export const config = {
  matcher: ['/((?!_next/static|_next/image|favicon.ico|public|robots.txt).*)'],
};

import { prisma } from './db';
import { redis } from './redis';

// Admin authorization helper
export async function isAdmin(userId: string): Promise<boolean> {
  // In production, check admin flag in database
  // For Stage 5, we use an env-based admin list
  const adminEmails = (process.env.ADMIN_EMAILS || '').split(',').map(e => e.trim().toLowerCase());

  const user = await prisma.user.findUnique({
    where: { id: userId },
    select: { email: true },
  });

  return user ? adminEmails.includes(user.email.toLowerCase()) : false;
}

// Admin stats
export async function getSystemStats() {
  const [
    totalUsers,
    totalMemories,
    totalConversations,
    totalGoals,
    activeToday,
    recentSignups,
  ] = await Promise.all([
    prisma.user.count(),
    prisma.memory.count({ where: { status: 'ACTIVE' } }),
    prisma.conversation.count(),
    prisma.goal.count({ where: { status: 'ACTIVE' } }),
    prisma.user.count({
      where: {
        sessions: {
          some: {
            lastSeenAt: { gte: new Date(Date.now() - 24 * 60 * 60 * 1000) },
          },
        },
      },
    }),
    prisma.user.count({
      where: {
        createdAt: { gte: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000) },
      },
    }),
  ]);

  return {
    totalUsers,
    totalMemories,
    totalConversations,
    totalGoals,
    activeToday,
    recentSignups,
  };
}

// Get user list for admin
export async function getUserList(page = 1, pageSize = 50) {
  const skip = (page - 1) * pageSize;

  const [users, total] = await Promise.all([
    prisma.user.findMany({
      skip,
      take: pageSize,
      orderBy: { createdAt: 'desc' },
      select: {
        id: true,
        name: true,
        email: true,
        createdAt: true,
        memoryPaused: true,
        _count: {
          select: {
            memories: true,
            conversations: true,
            goals: true,
          },
        },
      },
    }),
    prisma.user.count(),
  ]);

  return {
    users,
    pagination: {
      page,
      pageSize,
      total,
      totalPages: Math.ceil(total / pageSize),
    },
  };
}

// Get audit logs for admin
export async function getAuditLogs(page = 1, pageSize = 100) {
  const skip = (page - 1) * pageSize;

  const [logs, total] = await Promise.all([
    prisma.auditLog.findMany({
      skip,
      take: pageSize,
      orderBy: { createdAt: 'desc' },
      include: {
        user: {
          select: { email: true, name: true },
        },
      },
    }),
    prisma.auditLog.count(),
  ]);

  return {
    logs,
    pagination: {
      page,
      pageSize,
      total,
      totalPages: Math.ceil(total / pageSize),
    },
  };
}

import { Queue, Worker } from 'bullmq';
import { redis } from './redis';

// BullMQ connection options
const connection = redis;

// Export job queue
export const exportQueue = new Queue('export-queue', { connection });

// Consolidation job queue (memory cleanup)
export const consolidationQueue = new Queue('consolidation-queue', { connection });

// Notification queue
export const notificationQueue = new Queue('notification-queue', { connection });

// Memory processing queue
export const memoryQueue = new Queue('memory-queue', { connection });

// Job types
export type ExportJobData = {
  userId: string;
  jobId: string;
  format: 'json' | 'csv';
};

export type ConsolidationJobData = {
  userId: string;
  threshold?: number;
};

export type NotificationJobData = {
  userId: string;
  type: string;
  payload: Record<string, unknown>;
};

// Add job helpers
export async function addExportJob(data: ExportJobData): Promise<string> {
  const job = await exportQueue.add('export-data', data, {
    attempts: 3,
    backoff: { type: 'exponential', delay: 5000 },
    removeOnComplete: { age: 3600 },
    removeOnFail: { age: 86400 },
  });
  return job.id!;
}

export async function addConsolidationJob(data: ConsolidationJobData): Promise<string> {
  const job = await consolidationQueue.add('consolidate-memories', data, {
    attempts: 2,
    backoff: { type: 'fixed', delay: 10000 },
    removeOnComplete: { age: 3600 },
  });
  return job.id!;
}

export async function addNotificationJob(data: NotificationJobData): Promise<string> {
  const job = await notificationQueue.add('send-notification', data, {
    attempts: 3,
    backoff: { type: 'exponential', delay: 30000 },
    delay: data.payload.scheduledAt ? new Date(data.payload.scheduledAt as string).getTime() - Date.now() : 0,
  });
  return job.id!;
}

// Queue health check
export async function checkQueueHealth(): Promise<{ healthy: boolean; queues: Record<string, number> }> {
  try {
    const [exportCount, consolidationCount, notificationCount, memoryCount] = await Promise.all([
      exportQueue.getWaitingCount(),
      consolidationQueue.getWaitingCount(),
      notificationQueue.getWaitingCount(),
      memoryQueue.getWaitingCount(),
    ]);

    return {
      healthy: true,
      queues: {
        export: exportCount,
        consolidation: consolidationCount,
        notification: notificationCount,
        memory: memoryCount,
      },
    };
  } catch {
    return {
      healthy: false,
      queues: {},
    };
  }
}

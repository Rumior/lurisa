'use client';

import { useState, useRef, useEffect, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Send, Loader2, Brain, Sparkles, Sunrise, Sunset } from 'lucide-react';

interface Message {
  id: string;
  role: 'USER' | 'ASSISTANT';
  content: string;
  createdAt: string;
}

interface ChatInterfaceProps {
  mode?: 'chat' | 'morning' | 'evening';
}

export function ChatInterface({ mode = 'chat' }: ChatInterfaceProps) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [conversationId, setConversationId] = useState<string | undefined>();
  const [streamingText, setStreamingText] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const abortControllerRef = useRef<AbortController | null>(null);

  useEffect(() => { loadConversations(); }, []);
  useEffect(() => { messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [messages, streamingText]);

  async function loadConversations() {
    try {
      const res = await fetch('/api/chat');
      if (res.ok) {
        const data = await res.json();
        if (data.conversations?.length > 0) {
          const conv = data.conversations[0];
          setConversationId(conv.id);
          const msgRes = await fetch(`/api/chat?conversationId=${conv.id}`);
          if (msgRes.ok) {
            const msgData = await msgRes.json();
            setMessages(msgData.messages || []);
          }
        }
      }
    } catch (error) { console.error('Failed to load conversations:', error); }
  }

  const handleSubmit = useCallback(async (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!input.trim() || isLoading) return;

    const userContent = input.trim();
    const userMessage: Message = {
      id: `temp-${Date.now()}`,
      role: 'USER',
      content: userContent,
      createdAt: new Date().toISOString(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);
    setStreamingText('');

    // Use streaming API
    try {
      abortControllerRef.current = new AbortController();
      const res = await fetch('/api/chat/stream', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ content: userContent, conversationId }),
        signal: abortControllerRef.current.signal,
      });

      if (!res.ok || !res.body) {
        throw new Error('Stream failed');
      }

      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let fullText = '';

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        const chunk = decoder.decode(value, { stream: true });
        const lines = chunk.split('\n');

        for (const line of lines) {
          if (line.startsWith('data: ')) {
            try {
              const data = JSON.parse(line.slice(6));
              if (data.chunk) {
                fullText += data.chunk;
                setStreamingText(fullText);
              }
              if (data.done) {
                setMessages((prev) => [...prev, {
                  id: data.messageId || `msg-${Date.now()}`,
                  role: 'ASSISTANT',
                  content: fullText,
                  createdAt: new Date().toISOString(),
                }]);
                setConversationId(data.conversationId);
                setStreamingText('');
              }
            } catch {
              // Ignore parse errors in stream
            }
          }
        }
      }
    } catch (error) {
      if ((error as Error).name !== 'AbortError') {
        setMessages((prev) => [...prev, {
          id: `error-${Date.now()}`,
          role: 'ASSISTANT',
          content: 'I apologize, but I encountered an issue. Could you try again?',
          createdAt: new Date().toISOString(),
        }]);
      }
    } finally {
      setIsLoading(false);
      abortControllerRef.current = null;
      textareaRef.current?.focus();
    }
  }, [input, isLoading, conversationId]);

  function handleKeyDown(e: React.KeyboardEvent) {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  }

  const modeConfig = {
    chat: { icon: <Sparkles className="h-5 w-5" />, title: 'Chat with lurisa', subtitle: 'Share what's on your mind' },
    morning: { icon: <Sunrise className="h-5 w-5 text-amber-500" />, title: 'Morning Check-in', subtitle: 'How are you feeling today?' },
    evening: { icon: <Sunset className="h-5 w-5 text-terracotta-500" />, title: 'Evening Reflection', subtitle: 'What did today teach you?' },
  };

  const config = modeConfig[mode];

  return (
    <div className="flex flex-col h-[calc(100vh-8rem)] max-h-[800px]">
      <div className="flex items-center space-x-3 mb-4 pb-4 border-b border-parchment-700/20">
        {config.icon}
        <div>
          <h2 className="font-serif text-indigo-500 dark:text-indigo-300">{config.title}</h2>
          <p className="text-xs text-charcoal-500">{config.subtitle}</p>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto space-y-4 pr-2 mb-4">
        {messages.length === 0 && !streamingText && (
          <EmptyChatState mode={mode} onSuggestion={(text) => { setInput(text); textareaRef.current?.focus(); }} />
        )}
        {messages.map((message) => (
          <MessageBubble key={message.id} message={message} />
        ))}
        {streamingText && (
          <MessageBubble message={{
            id: 'streaming',
            role: 'ASSISTANT',
            content: streamingText,
            createdAt: new Date().toISOString(),
          }} isStreaming />
        )}
        {isLoading && !streamingText && <TypingIndicator />}
        <div ref={messagesEndRef} />
      </div>

      <form onSubmit={handleSubmit} className="relative">
        <Textarea
          ref={textareaRef}
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder="Type your message..."
          className="min-h-[80px] pr-14 bg-parchment-100 dark:bg-indigo-900 dark:text-parchment-100 resize-none"
          disabled={isLoading}
        />
        <Button type="submit" size="icon" disabled={isLoading || !input.trim()} className="absolute right-3 bottom-3 h-9 w-9">
          {isLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
        </Button>
      </form>
    </div>
  );
}

function MessageBubble({ message, isStreaming }: { message: Message; isStreaming?: boolean }) {
  const isUser = message.role === 'USER';
  return (
    <div className={`flex ${isUser ? 'justify-end' : 'justify-start'}`}>
      <div className={`max-w-[80%] ${isUser ? 'ml-8' : 'mr-8'}`}>
        {!isUser && (
          <div className="flex items-center space-x-2 mb-1">
            <div className="h-6 w-6 rounded-full bg-indigo-500 flex items-center justify-center">
              <span className="text-parchment-100 text-xs font-serif">l</span>
            </div>
            <span className="text-xs text-charcoal-300">lurisa</span>
            {isStreaming && <Badge variant="outline" className="text-[10px]">Thinking...</Badge>}
          </div>
        )}
        <Card className={`${isUser ? 'bg-indigo-500 text-parchment-100' : 'bg-parchment-100 dark:bg-indigo-800 text-charcoal-700 dark:text-parchment-100'} border-0 journal-shadow`}>
          <div className="p-3 text-sm leading-relaxed whitespace-pre-wrap">{message.content}</div>
        </Card>
        <span className="text-[10px] text-charcoal-300 mt-1 block">
          {new Date(message.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
        </span>
      </div>
    </div>
  );
}

function TypingIndicator() {
  return (
    <div className="flex items-center space-x-2 text-charcoal-300">
      <div className="h-6 w-6 rounded-full bg-indigo-100 flex items-center justify-center">
        <Brain className="h-3 w-3 text-indigo-500 animate-pulse" />
      </div>
      <div className="flex space-x-1">
        <span className="w-1.5 h-1.5 bg-charcoal-300 rounded-full animate-typing" style={{ animationDelay: '0ms' }} />
        <span className="w-1.5 h-1.5 bg-charcoal-300 rounded-full animate-typing" style={{ animationDelay: '150ms' }} />
        <span className="w-1.5 h-1.5 bg-charcoal-300 rounded-full animate-typing" style={{ animationDelay: '300ms' }} />
      </div>
    </div>
  );
}

function EmptyChatState({ mode, onSuggestion }: { mode: string; onSuggestion: (text: string) => void }) {
  const suggestions: Record<string, string[]> = {
    chat: ['How are you feeling today?', 'What are you looking forward to?', 'What's been on your mind?', 'What made today meaningful?'],
    morning: ['I slept well, ready for the day', 'Feeling a bit anxious about today', 'Excited about my meeting later', 'Just taking it slow this morning'],
    evening: ['Today was productive', 'Had a difficult conversation', 'Learned something new', 'Grateful for small moments'],
  };
  return (
    <div className="text-center py-8">
      <div className="mx-auto h-12 w-12 rounded-full bg-indigo-100 dark:bg-indigo-800 flex items-center justify-center mb-4">
        <Brain className="h-6 w-6 text-indigo-500" />
      </div>
      <p className="text-sm text-charcoal-500 dark:text-parchment-300 mb-4">Start with one of these, or share your own thoughts:</p>
      <div className="flex flex-wrap justify-center gap-2">
        {suggestions[mode]?.map((suggestion) => (
          <button key={suggestion} onClick={() => onSuggestion(suggestion)} className="px-3 py-1.5 rounded-full bg-parchment-500 dark:bg-indigo-800 text-charcoal-500 dark:text-parchment-300 text-xs hover:bg-indigo-100 dark:hover:bg-indigo-700 transition-colors">
            {suggestion}
          </button>
        ))}
      </div>
    </div>
  );
}
